'use strict';

module.exports = require('sockjs-client');
