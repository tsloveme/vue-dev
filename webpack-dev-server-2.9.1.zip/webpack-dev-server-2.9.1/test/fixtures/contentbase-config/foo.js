'use strict';

require('./index.html'); // eslint-disable-line

console.log('Hey.');
