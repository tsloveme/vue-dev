'use strict';

console.log("Hey."); // eslint-disable-line
