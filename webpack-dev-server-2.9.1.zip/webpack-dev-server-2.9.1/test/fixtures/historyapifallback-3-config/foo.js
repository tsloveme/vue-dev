'use strict';

require('./bar.html');

console.log("Hey."); // eslint-disable-line
