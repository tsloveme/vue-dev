'use strict';

const myText = document.getElementById('mytext');

myText.textContent = 'Does it work? yes';
