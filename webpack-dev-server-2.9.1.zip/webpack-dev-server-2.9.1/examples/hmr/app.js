'use strict';

require('./hmr');
