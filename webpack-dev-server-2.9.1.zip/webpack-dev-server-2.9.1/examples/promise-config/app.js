'use strict';

// Change the following line and save to see the compilation status

document.write('It works!');
