# Promise-Based Config

```shell
node ../../bin/webpack-dev-server.js --open
```

## What should happen

The script should open the browser and show a heading with "Example: Promise Config".
