# host and port

For basic usage
```shell
node ../../bin/webpack-dev-server.js --bonjour
```

## What should happen

It should publish a zeroconf service with a type of `http` and a subtype of `webpack`.
