'use strict';

document.write("It's working.");
