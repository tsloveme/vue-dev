'use strict';

// Change the following line and save to see the compilation status

document.write('Change me to see compilation progress in console...');
