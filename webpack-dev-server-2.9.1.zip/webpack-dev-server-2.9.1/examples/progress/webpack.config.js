'use strict';

module.exports = {
  context: __dirname,
  entry: './app.js',
  devServer: {
    progress: true
  }
};
