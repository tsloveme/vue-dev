# Status

```shell
node ../../bin/webpack-dev-server.js --open
```

## What should happen

The script should open the browser and show a heading with "Example: progress".

In `app.js`, change the text and save. You should see the compilation progress in the browser console.
