'use strict';

/**/
module.exports = {
  target: 'http://jsonplaceholder.typicode.com/',
  pathRewrite: {
    '^/api': ''
  }
};
/**/

//
// Replace it with following and save the file:
//

/** /
module.exports = {
  target: 'http://reqres.in/'
};
/**/
