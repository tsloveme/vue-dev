'use strict';

if (window.location.href.endsWith('example.html#page1')) {
  document.write("It's working.");
}
