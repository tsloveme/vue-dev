'use strict';

document.write("It's working.");

// This results in an error:
// if(!window) require("test");
