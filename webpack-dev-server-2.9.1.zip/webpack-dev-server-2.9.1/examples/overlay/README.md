# Overlay

```shell
node ../../bin/webpack-dev-server.js --open
```

## What should happen

The script should open the browser and show a heading with "Example: overlay".

In `app.js`, make a syntax error. The page should now refresh and show a full screen error overlay that shows the syntax error.
