# Overlay

```shell
node ../../bin/webpack-dev-server.js --open
```

## What should happen

The script should open the browser and show a heading with "Example: overlay with warnings".

In `app.js`, uncomment the lines that should cause a warning to appear. The page should now refresh and show a full screen overlay that shows the warning.
