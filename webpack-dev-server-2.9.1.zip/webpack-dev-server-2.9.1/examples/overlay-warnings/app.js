'use strict';

document.write("It's working.");

// This results in a warning:
// require("./casesensitive.js");
// require("./caseSensitive.js");

// This results in an error:
// if(!window) require("test");
