'use strict';

console.log('case sensitive');
